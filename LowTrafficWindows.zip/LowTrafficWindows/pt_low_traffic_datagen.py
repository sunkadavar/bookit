import time
import random
from datetime import datetime, timedelta


def get_day_of_week(day: int) -> str:
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    return days[day % 7]

"""
Define container class to hold low traffic windows for set of interfaces in map style
"""
class LowTrafficWindows:
    def __init__(self):
        # map of interface name -> InterfaceLowTrafficWindows
        self.interfaces = {}

    def add_window(self, interface, window):    
        if interface not in self.interfaces:
            self.interfaces[interface] = InterfaceLowTrafficWindows(interface)
        self.interfaces[interface].add_window(window)

    def to_dict(self):
        return {
            "interfaces": {name: iface.to_dict() for name, iface in self.interfaces.items()},
        }

"""
Module which generates the low traffic windows
The low traffic window is defined as below:
{
  "window_size": 30,
  "day_of_week": 5,
  "start_time": "02:00", # epoch seconds
  "end_time": "05:00",   # epoch seconds
  "date": "2025-10-01",
}

day of week: 0=Mon, 1=Tue, ..., 6=Sun
start_time, end_time: in HH:MM format, 24-hour clock
"""

class InterfaceLowTrafficWindows:
    def __init__(self, interface):
        self.interface = interface
        self.windows = []

    def add_window(self, window):
        self.windows.append(window)

    def to_dict(self):
        return {
            "interface": self.interface,
            "low_traffic_windows": self.windows,
        }

class LowTrafficWindow:
    def __init__(self, window_size, day_of_week, start_time, end_time, date):
        self.window_size = window_size
        self.day_of_week = day_of_week
        self.start_time = start_time
        self.end_time = end_time
        self.date = date

    def to_dict(self):
        return {
            "window_size": self.window_size,
            "day_of_week": self.day_of_week,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "date": self.date,
        }

def epoch_seconds_to_hourmin(epoch_seconds):
    t = time.gmtime(epoch_seconds)
    day = t.tm_mday
    hour = t.tm_hour
    minute = t.tm_min
    return f"{day:02}:{hour:02}:{minute:02}"


# generate low traffic windows during weekdays between 22 and 5 hours
def generate_low_traffic_windows_weekdays(interface, num_windows=5):
    low_traffic_windows = InterfaceLowTrafficWindows(interface)

    current_date = datetime.now()

    for _ in range(num_windows):
        # Randomly choose a day of the week (0=Mon, 1=Tue, ..., 6=Sun)
        day_of_week = random.randint(0, 6)

        # Get day of week as string
        day_str = get_day_of_week(day_of_week)

        # Randomly choose a start time between 22:00 and 05:00 of the next day
        # Minimum window size is 4 hours, maximum is 7 hours
        window_size = random.randint(4, 8)
        if day_of_week < 5:  # Weekday
            start_hour = random.randint(22, 23)
            start_minute = 00
            start_time = f"{start_hour:02}:{start_minute:02}"
            end_hour = (start_hour + window_size) % 24
            end_minute = 00
            end_time = f"{end_hour:02}:{end_minute:02}"
        else:  # Weekend
            start_hour = random.randint(0, 5)
            start_minute = 00
            start_time = f"{start_hour:02}:{start_minute:02}"
            end_hour = (start_hour + window_size) % 24
            end_minute = 00
            end_time = f"{end_hour:02}:{end_minute:02}"

        # Window size should be calculated based on start and end time
        window_size = ((end_hour + (24 if end_hour < start_hour else 0)) * 60 + end_minute) - (start_hour * 60 + start_minute)
        window_size = window_size / 60 if window_size > 0 else 0
        window_size = int(window_size)
        if window_size < 1:
            window_size = 1

         # Calculate the date for the chosen day of the week
        days_ahead = (day_of_week - current_date.weekday() + 7) % 7
        target_date = current_date + timedelta(days=days_ahead)
        date_str = target_date.strftime("%Y-%m-%d")

        low_traffic_window = LowTrafficWindow(
            window_size=window_size,
            day_of_week=day_str,
            start_time=start_time,
            end_time=end_time,
            date=date_str
        )
        low_traffic_windows.add_window(low_traffic_window.to_dict())
    return low_traffic_windows

# Function which generates low traffic windows during weekends and late nights
# For each interface, there will be randomly generated low traffic windows during saturday and
# sunday between 20 and 5 hours of the next day and late nights on weekdays
# between 22 and 5 hours. The window size will be of random size between 4 and 8 hours.
def generate_low_traffic_windows_weekends(interface, num_windows=3):
    low_traffic_windows = InterfaceLowTrafficWindows(interface)

    current_date = datetime.now()

    for _ in range(num_windows):
        # Randomly choose a day of the week (0=Mon, 1=Tue, ..., 6=Sun)
        day_of_week = random.choice([5, 6])  # Saturday or Sunday
        day_str = get_day_of_week(day_of_week)

        # Randomly choose a start time between 20:00 and 05:00 of the next day
        # Minimum window size is 4 hours, maximum is 24 hours
        window_size = random.randint(4, 8)
        if day_of_week == 5:  # Saturday
            start_hour = random.randint(20, 23)
            start_minute = 00
            start_time = f"{start_hour:02}:{start_minute:02}"
            end_hour = (start_hour + window_size) % 24
            end_minute = 00
            end_time = f"{end_hour:02}:{end_minute:02}"
        else:  # Sunday
            start_hour = random.randint(20, 23)
            start_minute = 00
            start_time = f"{start_hour:02}:{start_minute:02}"
            end_hour = (start_hour + window_size) % 24
            end_minute = 00
            end_time = f"{end_hour:02}:{end_minute:02}"

        # Window size should be calculated based on start and end time
        window_size = ((end_hour + (24 if end_hour < start_hour else 0)) * 60 + end_minute) - (start_hour * 60 + start_minute)
        window_size = window_size / 60 if window_size > 0 else 0
        window_size = int(window_size)
        if window_size < 1:
            window_size = 1

         # Calculate the date for the chosen day of the week
        days_ahead = (day_of_week - current_date.weekday() + 7) % 7
        target_date = current_date + timedelta(days=days_ahead)
        date_str = target_date.strftime("%Y-%m-%d")

        low_traffic_window = LowTrafficWindow(
            window_size=window_size,
            day_of_week=day_str,
            start_time=start_time,
            end_time=end_time,
            date=date_str
        )
        low_traffic_windows.add_window(low_traffic_window.to_dict())

    return low_traffic_windows


if __name__ == "__main__":
    interface = "eth0"
    low_traffic_windows_weekdays = generate_low_traffic_windows_weekdays(interface, num_windows=5)
    print(low_traffic_windows_weekdays.to_dict())
    low_traffic_windows_weekends = generate_low_traffic_windows_weekends(interface, num_windows=3)
    print(low_traffic_windows_weekends.to_dict())

    LowTrafficWindowsAll = LowTrafficWindows()
    for window in low_traffic_windows_weekdays.windows:
        LowTrafficWindowsAll.add_window(interface, window)
    for window in low_traffic_windows_weekends.windows:
        LowTrafficWindowsAll.add_window(interface, window)

    print(LowTrafficWindowsAll.to_dict())

    # Write Low traffic windows to EXCEL file with interface name as one column
    # Sheet name: low_traffic_sample_set_1
    # wrap the text in the cells
    import pandas as pd
    df = pd.DataFrame(LowTrafficWindowsAll.to_dict()['interfaces'][interface]['low_traffic_windows'])
    df['interface'] = interface
    df.to_excel("low_traffic_windows_2.xlsx", 
                index=False, 
                sheet_name="low_traffic_sample_set_2",
                startrow=3,
                startcol=3,
                header=True
                )
    
    # write to csv file
    df.to_csv("low_traffic_windows_2.csv", index=False)
