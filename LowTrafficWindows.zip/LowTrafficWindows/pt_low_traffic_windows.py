from typing import List, Tuple, Optional
import bisect
import pandas as pd


# Let's save the computed maximum length overlapping window
# Consider this stored overlapping window as one of the input window to next computation
stored_window = None

# helpers
DAY_TO_IDX = {
    'mon':0, 'Monday':0,
    'tue':1, 'Tuesday':1,
    'wed':2, 'Wednesday':2,
    'thu':3, 'Thursday':3,
    'fri':4, 'Friday':4,
    'sat':5, 'Saturday':5,
    'sun':6, 'Sunday':6
}
MINUTES_PER_DAY = 24*60
MINUTES_PER_WEEK = 7 * MINUTES_PER_DAY

# Function to return day of week in string when given an integer
def get_day_of_week(day: int) -> str:
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    return days[day % 7]

def parse_time(hm: str) -> int:
    """'HH:MM' -> minutes since midnight"""
    h, m = hm.split(':')
    return int(h)*60 + int(m)

def to_week_min(day: str, hm: str) -> int:
    idx = DAY_TO_IDX[day.strip().lower()]
    return idx * MINUTES_PER_DAY + parse_time(hm)

def minute_to_daytime(minute: int) -> Tuple[str, str]:
    minute = minute % MINUTES_PER_WEEK
    day_idx = minute // MINUTES_PER_DAY
    t = minute % MINUTES_PER_DAY
    hh = t // 60
    mm = t % 60
    day_names = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    return day_names[day_idx], f"{hh:02d}:{mm:02d}"

def split_interval_week(a: int, b: int) -> List[Tuple[int,int]]:
    """
    a,b are minute offsets in 0..10079 interpreted on the infinite timeline.
    We assume the caller gives a start minute (a) and end minute (b) such that
    if b > a -> single interval [a,b)
    if b <= a -> wraps to next day/week -> will be split into [a, WEEK) and [0, b)
    We'll produce half-open intervals [start, end) in minute units.
    """
    if b > a:
        return [(a,b)]
    elif b == a:
        # Zero-length window -> interpreted as full-day? (Probably zero-length) treat as single point -> empty
        return []
    else:
        # wraps to next day/week
        return [(a, MINUTES_PER_WEEK), (0, b)]

def normalize_windows(windows: List[Tuple[str,str,str]]) -> List[Tuple[int,int]]:
    """
    Input windows: list of (day, start_time 'HH:MM', end_time 'HH:MM')
    Return list of half-open numeric intervals [(start_min, end_min), ...] inside 0..10080 (may split wraps).
    """
    intervals = []
    for day, s, e in windows:
        start = to_week_min(day, s)
        end = to_week_min(day, e)  # same-day minute
        # If end <= start, it wraps to next day
        if end <= start:
            end += MINUTES_PER_DAY
        for a,b in split_interval_week(start, end):
            intervals.append((a,b))
    return intervals

def recompute_max_window(windows: List[Tuple[str,str,str]]):
    """
    windows: list of (day_of_week, start_HH:MM, end_HH:MM)
    Returns:
      max_count: int (maximum overlapping windows)
      best_segment: (start_minute, end_minute) longest contiguous half-open interval where overlap == max_count
      best_segment_human: (start_day,start_time, end_day,end_time)
    If no windows, returns (0, None, None)
    """
    if not windows:
        return 0, None, None

    intervals = normalize_windows(windows)
    if not intervals:
        return 0, None, None
    
    # print intervals for debugging
    print("Normalized intervals (in minutes):")
    for start, end in intervals:
        print(f"  [{start}, {end})")

    events = []
    # We treat intervals as half-open [start, end) so end time is exclusive.
    for a,b in intervals:
        events.append((a, 1))   # start -> +1
        events.append((b, -1))  # end -> -1

    # sort by time; tie-break: starts before ends -> we sort by (time, -delta)
    events.sort(key=lambda x: (x[0], -x[1]))

    cur = 0
    max_count = 0
    # first pass to find max_count
    for t, delta in events:
        cur += delta
        if cur > max_count:
            max_count = cur

    # second pass to collect segments where cur == max_count
    segments = []
    cur = 0
    seg_start = None
    for t, delta in events:
        prev = cur
        cur += delta
        # We examine the half-open region starting at t and ending at next event time.
        # But easier: mark entering/exiting states: when cur becomes max_count we start segment at t
        # when cur drops from max_count we end segment at t
        if prev < max_count and cur == max_count:
            seg_start = t
        elif prev == max_count and cur < max_count:
            seg_end = t
            if seg_start is not None and seg_end > seg_start:
                segments.append((seg_start, seg_end))
            seg_start = None

    # Post: possibly a segment continues till end of week
    if seg_start is not None:
        # segment runs until end-of-week (10080)
        segments.append((seg_start, MINUTES_PER_WEEK))

    # Among collected segments choose the longest (largest duration)
    if not segments:
        return max_count, None, None

    best = max(segments, key=lambda seg: seg[1]-seg[0])
    best_start, best_end = best
    start_day, start_time = minute_to_daytime(best_start)
    end_day, end_time = minute_to_daytime(best_end % MINUTES_PER_WEEK)
    best_human = (start_day, start_time, end_day, end_time)
    return max_count, (best_start, best_end), best_human



# Example usage
if __name__ == "__main__":
    # sample windows: (day, start, end)
    windows = [
        ("Mon","22:00","23:30"),
        ("Tue","00:00","02:00"),   # this overlaps Mon 22:00..Tue 02:00 if interpreted continuous -> represented as Mon22:00..Mon24:00 + Tue0..2
        ("Mon","23:00","01:00"),   # wraps to Tue 01:00
        ("Tue","00:30","03:00"),
        ("Tue","01:30","05:00"),
        ("Wed","10:00","12:00"),
    ]

    # load the windows from CSV for testing
    df = pd.read_csv("low_traffic_windows.csv")
    print(df.head())
    windows = []
    for index, row in df.iterrows():
        print(row)  # Debug: print the row to see its structure
        day = row["day_of_week"]
        start = row["start_time"]
        end = row["end_time"]
        windows.append((day, start, end))
    
    # print the windows for verification
    print("Loaded windows:")
    for w in windows:
        print(w)

    max_count, best_seg, best_human = recompute_max_window(windows)
    print("max_count =", max_count)
    if best_seg:
        print("best_segment_minutes =", best_seg)
        print("best_human-1 =", best_human)
        # Save the best segment for future use
        #  best_human = (start_day, start_time, end_day, end_time)
        stored_window = {
            "start_day": best_human[0],
            "start_time": best_human[1],
            "end_day": best_human[2],
            "end_time": best_human[3],
        }
    else:
        print("No contiguous best segment found.")

    # If the stored window spread over multiple days, we can split it into multiple windows
    """
    stored_window = {
        "start_day": "Thu",
        "start_time": "22:00",
        "end_day": "Sat",
        "end_time": "03:00",
    }
    """
    if stored_window:
        split_windows = []
        start_day = stored_window["start_day"]
        start_time = stored_window["start_time"]
        end_day = stored_window["end_day"]
        end_time = stored_window["end_time"]

        if start_day == end_day:
            # same day, single window
            split_windows.append((start_day, start_time, end_time))
        else:
            # multiple days, split into multiple windows
            day_names = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
            start_idx = day_names.index(start_day)
            end_idx = day_names.index(end_day)

            # First window from start_time to midnight of start_day
            split_windows.append((start_day, start_time, "24:00"))

            # Intermediate full-day windows
            for i in range((start_idx + 1) % 7, end_idx):
                split_windows.append((day_names[i], "00:00", "24:00"))

            # Last window from midnight to end_time of end_day
            split_windows.append((end_day, "00:00", end_time))

        print("Split windows from stored_window:")
        for w in split_windows:
            print(w)
        
        # Load second sample windows from low_traffic_windows_2.csv and include the split windows
        df2 = pd.read_csv("low_traffic_windows_2.csv")
        print(df2.head())
        windows2 = []
        for index, row in df2.iterrows():
            print(row)  # Debug: print the row to see its structure
            day = row["day_of_week"]
            start = row["start_time"]
            end = row["end_time"]
            windows2.append((day, start, end))
        # Combine with split windows
        windows2.extend(split_windows)
        print("Combined windows for second computation:")
        for w in windows2:
            print(w)
        max_count2, best_seg2, best_human2 = recompute_max_window(windows2)
        print("Second computation:")
        print("max_count =", max_count2)
        if best_seg2:
            print("best_segment_minutes =", best_seg2)
            print("best_human-2 =", best_human2)
        else:
            print("No contiguous best segment found.")

    # Testing wrapping window to next day
    wrap_windows = [
       ('Mon', '23:00', '05:00'),   # wraps to Tue 05:00
       ('Tue', '01:00', '05:00'),
       ('Tue', '02:00', '06:00'),
       ('Mon', '23:00', '05:00'),
       ('Tue', '02:00', '05:00'),
    ]
    max_count_wrap, best_seg_wrap, best_human_wrap = recompute_max_window(wrap_windows)
    print("Wrapping window test:")
    print("max_count =", max_count_wrap)
    if best_seg_wrap:
        print("best_segment_minutes =", best_seg_wrap)
        print("best_human-3 =", best_human_wrap)
    else:
        print("No contiguous best segment found.")

    # Weekend spanning example
    weekend_windows = [
       ('Sat', '20:00', '04:00'),   # wraps to Sun 04:00
       ('Sun', '23:00', '05:00'),
       ('Sun', '22:00', '04:00'),
       ('Sat', '22:00', '03:00'),
       ('Sun', '23:00', '04:00'),
    ]
    max_count_weekend, best_seg_weekend, best_human_weekend = recompute_max_window(weekend_windows)
    print("Weekend spanning window test:")
    print("max_count =", max_count_weekend)
    if best_seg_weekend:
        print("best_segment_minutes =", best_seg_weekend)
        print("best_human-4 =", best_human_weekend)
    else:
        print("No contiguous best segment found.")
